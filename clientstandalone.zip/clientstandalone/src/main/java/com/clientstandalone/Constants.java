package com.clientstandalone;

public class Constants {

	public static String SERVICE_URL = "service_url";

	public static String XSD_NAME_PATH_TAG = "empns:formid";

	public static String BASIC_XSD = "basic_xsd";

	public static String XSD_MAPPING_INITIAL = "formid_xsd_mapping_";

	public static String OUTPUT_FILE = "output_file";
}
